/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hashfunctions.functions;

import hashfunctions.FileToHash;
import java.io.IOException;
import utils.hashing.ssdeep.SsdeepUtils;

public class Fuzzy implements HashFunction {

    @Override
    public Hash calculateHash(FileToHash file) throws HashFunctionException {
        
        try {
                
            SsdeepUtils ssDeep = new SsdeepUtils();
            String ssDeepHash = ssDeep.fuzzy_hash_file(file.getFilePath());
                                 
            return new Hash(file.getFileName(), ssDeepHash, "Fuzzy");
            
        } catch (IOException ex) {
            throw new HashFunctionException(ex);
        }
    }
    
}
