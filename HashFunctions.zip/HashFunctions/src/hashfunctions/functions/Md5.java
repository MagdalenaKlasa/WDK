/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hashfunctions.functions;

import hashfunctions.FileToHash;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class Md5 implements HashFunction {

    @Override
    public Hash calculateHash(FileToHash file) throws HashFunctionException {
                      
        byte[] digest;
        
        try {
            digest = MessageDigest.getInstance("MD5").digest(file.getFileContent());
        } catch (NoSuchAlgorithmException ex) {
            throw new HashFunctionException(ex);
        }
        
        return new Hash(file.getFileName(), digest, "MD5");
    }
}
