/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hashfunctions.functions;

public class Hash {
    
    private final String _fileName;
    private final String _hash;
    private final String _hashFunction;

    public Hash(String _fileName, String _hash, String _hashFunction) {
        this._fileName = _fileName;
        this._hash = _hash;
        this._hashFunction = _hashFunction;
    }

    public Hash(String _fileName, byte[] _hash, String _hashFunction) {
        this._fileName = _fileName;
        this._hash = convertByteArrayHashToString(_hash);
        this._hashFunction = _hashFunction;
    }
    
    private static String convertByteArrayHashToString(byte[] _hash) {
        
        StringBuilder sb = new StringBuilder();
        
        if(_hash != null) {
            for (byte b : _hash) {
                sb.append(String.format("%02X", b));
            }
        }
        
        return sb.toString();
    }
       
    @Override
    public String toString() {
                
        return 
                "Function: " + _hashFunction + "\r\n" +
                "File: " + _fileName + "\r\n" +
                "Hash: " + _hash;
    }
}
