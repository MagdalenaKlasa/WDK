/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hashfunctions;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class FileToHash {
    
    private final byte[] _fileContent;
    private final String _fileName;
    private final String _filePath;
    
    public FileToHash(String filePath) throws IOException {
            
        Path path = Paths.get(filePath);
        
        _filePath = filePath;
        _fileName = path.getFileName().toString();
        _fileContent = Files.readAllBytes(path);
    }
       
    public String getFilePath() {
        return _filePath;
    }

    public byte[] getFileContent() {
        return _fileContent;
    }

    public String getFileName() {
        return _fileName;
    }
}
