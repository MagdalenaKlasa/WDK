/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hashfunctions;

import hashfunctions.functions.Hash;
import hashfunctions.functions.HashFunctionException;
import java.util.ArrayList;
import java.util.List;
import hashfunctions.functions.HashFunction;

public class HashFunctionsRunner {
    
    public List<Hash> run(List<FileToHash> files, List<HashFunction> functions) throws HashFunctionException {
        
        List<Hash> hashes = new ArrayList<>();
        
        for(short i=0;files.size()>i;i++){
            for(short j=0;functions.size()>j;j++){ 
                
                hashes.add(functions.get(j).calculateHash(files.get(i)));
                
            }    
        }
        
        return hashes;       
    }
    
}
