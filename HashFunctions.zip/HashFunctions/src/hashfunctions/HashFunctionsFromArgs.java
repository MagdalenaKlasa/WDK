/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hashfunctions;

import hashfunctions.functions.Hash;
import hashfunctions.functions.HashFunctionException;
import hashfunctions.functions.Md5;
import hashfunctions.functions.Sha256;
import hashfunctions.functions.Fuzzy;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import hashfunctions.functions.HashFunction;

public class HashFunctionsFromArgs {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
           
        try {
            
            List<FileToHash> filesFromArgs = getFilesFromArgs(args);
            List<HashFunction> hashFunctions = getHashFunctions();
            
            List<Hash> results = 
                    new HashFunctionsRunner()
                            .run(filesFromArgs, hashFunctions);
            
            printResults(results);
            
        } catch (HashFunctionException | IOException ex) {
            Logger.getLogger(HashFunctionsFromArgs.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
        
    private static List<FileToHash> getFilesFromArgs(String[] args) throws IOException {
        
        List<FileToHash> files = new ArrayList<>();

        for(short i = 0; args.length>i;i++) {
            files.add(new FileToHash(args[i]));
        }
        
        return files;
    }
    
    private static List<HashFunction> getHashFunctions() {
        
        return new ArrayList<HashFunction>() {{
            add(new Md5());
            add(new Sha256());
            add(new Fuzzy());
        }}; 
    }
    
    private static void printResults(List<Hash> hashes) {
        
        for(short i = 0; hashes.size()>i;i++) {
            System.out.println("-----");
            System.out.println(hashes.get(i));
            System.out.println("-----");
        }   
    }
}
