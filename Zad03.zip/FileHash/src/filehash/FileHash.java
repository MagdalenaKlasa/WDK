/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package filehash;

import functions.BlockHash;
import functions.Sha256Exception;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import utils.FileUtils;

public class FileHash {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        if(args.length > 1)
        {
            try {
                
                byte[] data = FileUtils.getDataFromFile(args[0]);
                               
                BlockHash blockHash = new BlockHash();
                byte[] hash = blockHash.calculateHash(data);
                                
                FileUtils.saveDataToHexFile(args[1], hash);
                return;
                
            } catch (IOException | Sha256Exception ex) {
                Logger.getLogger(FileHash.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
        System.out.println("Jako argumenty, program przyjmuje ścieżki do pliku wejściowego oraz wyjściowego.");
    }
    
}
