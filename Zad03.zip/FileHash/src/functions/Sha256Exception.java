/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package functions;

public class Sha256Exception extends Exception {

    Sha256Exception(Exception ex) {
        super(ex);
    }
    
}
