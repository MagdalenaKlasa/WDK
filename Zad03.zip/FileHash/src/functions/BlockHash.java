/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package functions;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.apache.commons.lang3.ArrayUtils;

public class BlockHash {
        
    private final short chunkSize = 1024;
    private final Sha256 sha = new Sha256();
        
    public byte[] calculateHash(byte[] data) throws Sha256Exception {
        
        List<byte[]> chunks = split(data);
        byte[] hash = new byte[0];
                        
        for(int i=chunks.size()-1; i>0; i--) {            
            hash =  ArrayUtils.addAll(chunks.get(i-1), sha.calculateHash(chunks.get(i)));  
        }
        
        return sha.calculateHash(hash);
    }
    
    private List<byte[]> split(byte[] data) {
        
        int dataLength = data.length;

        List<byte[]> chunks = new ArrayList();
        
        for(int i = 0; i < dataLength/chunkSize; i++)
           chunks.add(Arrays.copyOfRange(data, dataLength - chunkSize, dataLength));
        
        int modulo = dataLength % chunkSize;
        
        if(modulo != 0)         
            chunks.add(Arrays.copyOfRange(data, 0, modulo));
        
        return chunks;
    }
}
