/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import org.apache.commons.codec.binary.Hex;

public class FileUtils {
        
    public static byte[] getDataFromFile(String filePath) throws IOException {
        
        Path path = Paths.get(filePath);
        return Files.readAllBytes(path);
    }
        
    public static void saveDataToHexFile(String filePath, byte[] data) throws FileNotFoundException {
        
        String hex = Hex.encodeHexString(data);
            
        try(PrintWriter out = new PrintWriter(filePath)){
            out.print(hex);
        }       
    }
    
}


